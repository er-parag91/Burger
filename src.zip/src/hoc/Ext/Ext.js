const ext = props => props.children;

export default ext;
