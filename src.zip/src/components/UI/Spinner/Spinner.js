import classes from './Spinner.css';
import React from 'react';

const spinner = () => (
  <div className={classes.Loader}>
    Loading..!
  </div>
);

export default spinner;
